module.exports = {
    port: 3000,
    redisHost: 'localhost',
    redisPort: 6379,
    influxDB: {
        url: 'http://localhost:8086',  // URL InfluxDB
        token: 'my-token',             // Токен для доступа к InfluxDB
        org: 'myorg',                  // Организация
        bucket: 'mybucket'             // Бакет для хранения данных
    }
};