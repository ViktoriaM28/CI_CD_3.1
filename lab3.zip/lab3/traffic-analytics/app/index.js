const express = require('express');
const { InfluxDB, Point } = require('@influxdata/influxdb-client');

const app = express();
const port = 3000;

// Конфигурация InfluxDB
const influxDB = new InfluxDB({
  url: process.env.INFLUXDB_URL,
  token: process.env.INFLUXDB_TOKEN,
});

const writeApi = influxDB.getWriteApi(process.env.INFLUXDB_ORG, process.env.INFLUXDB_BUCKET);

// Функция генерации данных о посещениях сайта
function generateWebsiteTrafficData() {
  const pages = ['/', '/about', '/products', '/contact'];
  const data = {
    page: pages[Math.floor(Math.random() * pages.length)],
    userId: `user${Math.floor(Math.random() * 1000)}`,
    timestamp: new Date().toISOString()
  };
  return data;
}

// Функция для периодической генерации данных о посещениях сайта
async function generateAndStoreWebsiteTraffic() {
  const data = generateWebsiteTrafficData();

  // Создаем точку данных для InfluxDB
  const point = new Point('website_traffic')
    .tag('page', data.page)
    .tag('userId', data.userId)
    .timestamp(new Date(data.timestamp));

  // Записываем данные в InfluxDB
  writeApi.writePoint(point);
  console.log('Generated website traffic:', data);
}

// Генерация данных о посещениях каждые 2 секунды
setInterval(generateAndStoreWebsiteTraffic, 2000);

// Запуск сервера
app.listen(port, () => {
  console.log(`App listening at http://localhost:${port}`);
});